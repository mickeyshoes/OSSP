package com.example.testlist;
// 리스트에 들어갈 항목을 정의하는 클래스.
public class FriendsItem {
    private int profile;
    private String info;
    private String phone;

    public int getProfile(){
        return profile;
    }
    public String getInfo(){
        return info;
    }
    public String getPhone(){
        return phone;
    }


    public FriendsItem(int profile, String info, String phone){
        this.profile = profile;
        this.info = info;
        this.phone = phone;
    }
}
