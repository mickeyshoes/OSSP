package com.example.testlist;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class FriendsList extends Activity implements View.OnClickListener {

    private ArrayList<FriendsItem> data = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.friends_list);

        ListView listView = (ListView) findViewById(R.id.friends_listview);

        // 1번 아이템
        FriendsItem friends1 = new FriendsItem(R.drawable.profile, "김도움 여 컴퓨터", "010-3525-3245");
        // 2번 아이템
        FriendsItem friends2 = new FriendsItem(R.drawable.profile2, "강도움 남 전기전자", "010-5243-5324");

        // 리스트에 추가
        data.add(friends1);
        data.add(friends2);

        // 리스트 속의 아이템 연결
        FriendsAdapter adapter = new FriendsAdapter(this, R.layout.friends_item, data);
        listView.setAdapter(adapter);

        // 아이템 클릭 시 작동
        // Intent를 통해서 다음 액티비티로 넘겨줌.
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), FriendsClicked.class);
                // putExtra의 첫 값은 식별 태그, 뒤에는 다음 화면에 넘길 값
                intent.putExtra("profile", Integer.toString(data.get(position).getProfile()));
                intent.putExtra("info", data.get(position).getInfo());
                intent.putExtra("phone", data.get(position).getPhone());
                startActivity(intent);
            }
        });
    }
    @Override
    public void onClick(View v){

    }

}
